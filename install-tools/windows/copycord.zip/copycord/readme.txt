Using the Copycord Launcher (Copycord.exe)

The launcher MUST be inside the folder where Copycord will live

Setup:

Create a folder

Put Copycord.exe in that folder

First-time install:

Double-click Copycord.exe

Choose: 1) Install Copycord

Wait for it to finish

Update Copycord:

Double-click Copycord.exe

Choose: 2) Update Copycord

Run Copycord:

Option A: Double-click Copycord.exe and choose 3) Run Copycord

Option B: Double-click copycord_windows.bat directly